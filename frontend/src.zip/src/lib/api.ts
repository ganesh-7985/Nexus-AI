/**
 * Nexus AI — API client for the FastAPI backend
 */

import { supabase } from "@/lib/supabase";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

/* ── Auth token helper ───────────────────────────────────────────── */

async function getToken(): Promise<string | null> {
  // getSession returns cached session; check if it's still valid
  const { data } = await supabase.auth.getSession();
  const session = data.session;
  if (!session) return null;

  // If token expires within 60s, force a refresh
  const expiresAt = session.expires_at ?? 0; // unix seconds
  const now = Math.floor(Date.now() / 1000);
  if (expiresAt - now < 60) {
    const { data: refreshed } = await supabase.auth.refreshSession();
    return refreshed.session?.access_token ?? session.access_token;
  }

  return session.access_token;
}

/* ── REST helpers ─────────────────────────────────────────────────── */

async function fetchJSON<T = unknown>(
  path: string,
  opts?: RequestInit,
): Promise<T> {
  const token = await getToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(opts?.headers as Record<string, string> || {}),
  };
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  const res = await fetch(`${BASE_URL}${path}`, {
    ...opts,
    headers,
  });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || JSON.stringify(body);
    } catch {}
    throw new Error(`API ${res.status}: ${detail}`);
  }
  return res.json();
}

/* ── Config ───────────────────────────────────────────────────────── */

export interface LLMConfig {
  api_type: string;
  model: string;
  base_url: string;
  has_key: boolean;
}

export async function getConfig(): Promise<LLMConfig> {
  return fetchJSON("/api/config");
}

export async function updateConfig(body: {
  api_type?: string;
  api_key?: string;
  model?: string;
  base_url?: string;
  gcp_project_id?: string;
  gcp_location?: string;
}): Promise<{ status: string }> {
  return fetchJSON("/api/config", {
    method: "PUT",
    body: JSON.stringify(body),
  });
}

/* ── Projects ─────────────────────────────────────────────────────── */

export interface BackendProject {
  id: string;
  name: string;
  prompt: string;
  status: string;
  workspace_path?: string;
}

export async function createBackendProject(
  prompt: string,
  name?: string,
): Promise<BackendProject> {
  return fetchJSON("/api/projects", {
    method: "POST",
    body: JSON.stringify({ prompt, name }),
  });
}

export async function getBackendProject(id: string): Promise<BackendProject> {
  return fetchJSON(`/api/projects/${id}`);
}

export async function listBackendProjects(): Promise<BackendProject[]> {
  return fetchJSON("/api/projects");
}

export async function deleteBackendProject(id: string): Promise<{ status: string }> {
  return fetchJSON(`/api/projects/${id}`, { method: "DELETE" });
}

/* ── Publish ──────────────────────────────────────────────────────── */

export interface PublishResult {
  status: string;
  download_url: string;
  files_url: string;
  workspace: string;
  preview_url?: string;
  error?: string;
}

export async function publishProject(id: string): Promise<PublishResult> {
  return fetchJSON(`/api/projects/${id}/publish`, { method: "POST" });
}

export function getDownloadUrl(id: string): string {
  return `${BASE_URL}/api/projects/${id}/download`;
}

export function getPreviewUrl(id: string): string {
  return `${BASE_URL}/preview/${id}/`;
}

export function getPublishedUrl(id: string): string {
  return `${BASE_URL}/published/${id}/`;
}

export interface ProjectFile {
  path: string;
  size: number;
  content: string;
}

export async function getProjectFiles(
  id: string,
): Promise<{ files: ProjectFile[]; workspace: string }> {
  return fetchJSON(`/api/projects/${id}/files`);
}

export async function updateProjectFile(
  id: string,
  filePath: string,
  content: string,
): Promise<{ status: string; path: string }> {
  return fetchJSON(
    `/api/projects/${id}/file?path=${encodeURIComponent(filePath)}`,
    { method: "PUT", body: JSON.stringify({ content }) },
  );
}

/* ── Container Preview ────────────────────────────────────────────── */

export interface ContainerStatus {
  status: string;
  port?: number;
  framework?: string;
  url?: string;
  container_id?: string;
  message?: string;
}

export async function startContainer(id: string): Promise<ContainerStatus> {
  return fetchJSON(`/api/projects/${id}/container/start`, { method: "POST" });
}

export async function stopContainer(id: string): Promise<{ status: string }> {
  return fetchJSON(`/api/projects/${id}/container/stop`, { method: "POST" });
}

export async function getContainerStatus(id: string): Promise<ContainerStatus> {
  return fetchJSON(`/api/projects/${id}/container/status`);
}

export async function getContainerLogs(id: string, tail?: number): Promise<{ logs: string }> {
  const params = tail ? `?tail=${tail}` : "";
  return fetchJSON(`/api/projects/${id}/container/logs${params}`);
}

/* ── Framework ───────────────────────────────────────────────────── */

export interface FrameworkInfo {
  framework: string;
  display_name: string;
}

export async function getProjectFramework(id: string): Promise<FrameworkInfo> {
  return fetchJSON(`/api/projects/${id}/framework`);
}

/* ── Messages ────────────────────────────────────────────────────── */

export async function getProjectMessages(id: string): Promise<{ id: number; role: string; agent_name: string; content: string; created_at: string }[]> {
  return fetchJSON(`/api/projects/${id}/messages`);
}

/* ── Health ────────────────────────────────────────────────────────── */

export async function checkHealth(): Promise<boolean> {
  try {
    const res = await fetch(`${BASE_URL}/health`, {
      signal: AbortSignal.timeout(3000),
    });
    return res.ok;
  } catch {
    return false;
  }
}

/* ── WebSocket ────────────────────────────────────────────────────── */

export type WSEvent =
  | { type: "pipeline_start"; prompt: string }
  | { type: "agent_start"; agent_name: string; agent_role: string }
  | { type: "agent_done"; agent_name: string; agent_role: string }
  | { type: "message"; content: string; role: string; cause_by: string; sent_from: string; send_to: string }
  | { type: "review_request"; agent_name: string; artifact_type: string; content: string }
  | { type: "review_auto_approved"; artifact_type: string }
  | { type: "review_accepted"; artifact_type: string; modified: boolean }
  | { type: "complete"; workspace_path?: string }
  | { type: "error"; message: string; traceback?: string };

export async function connectPipelineWS(
  projectId: string,
  onEvent: (event: WSEvent) => void,
  onClose?: () => void,
): Promise<WebSocket> {
  const token = await getToken();
  const wsUrl = BASE_URL.replace(/^http/, "ws");
  const tokenParam = token ? `?token=${encodeURIComponent(token)}` : "";
  const ws = new WebSocket(`${wsUrl}/ws/run/${projectId}${tokenParam}`);

  ws.onopen = () => {
    console.log("[WS] Connection opened for project", projectId);
  };

  ws.onmessage = (ev) => {
    try {
      const data = JSON.parse(ev.data) as WSEvent;
      console.log("[WS] Event received:", data.type, data);
      onEvent(data);
    } catch (err) {
      console.error("[WS] Failed to process message:", ev.data, err);
    }
  };

  ws.onclose = () => onClose?.();
  ws.onerror = (err) => {
    console.error("[WS] Error:", err);
    onClose?.();
  };

  return ws;
}
