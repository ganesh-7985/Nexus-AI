import type { AgentRole, ChatMessage } from "./store";

/* ------------------------------------------------------------------ */
/*  Agent pipeline definition                                         */
/* ------------------------------------------------------------------ */

interface AgentStep {
  agentName: string;
  agentRole: AgentRole;
  thinkingDelay: number; // ms before "thinking" resolves
  generate: (prompt: string) => {
    content: string;
    checklist?: { text: string; done: boolean }[];
  };
}

const pipeline: AgentStep[] = [
  {
    agentName: "Alice",
    agentRole: "Product Manager",
    thinkingDelay: 2500,
    generate: (prompt) => ({
      content: `Here's my analysis and feature plan for: "${prompt}"`,
      checklist: [
        { text: `Core functionality — implement the main feature set described in the requirement`, done: true },
        { text: `User interface — clean, responsive UI with intuitive navigation`, done: true },
        { text: `Data persistence — save and load user data reliably`, done: true },
        { text: `Error handling — graceful error states and user feedback`, done: false },
        { text: `Testing — unit and integration tests for critical paths`, done: false },
      ],
    }),
  },
  {
    agentName: "Bob",
    agentRole: "Architect",
    thinkingDelay: 3000,
    generate: (prompt) => ({
      content: `## System Design\n\n**Architecture:** Component-based modular architecture\n**Stack:** React + TypeScript + TailwindCSS\n**State Management:** React Context + hooks\n**Data Layer:** REST API with JSON responses\n\n### Component Tree\n\`\`\`\nApp\n├── Layout\n│   ├── Header\n│   └── Sidebar\n├── Pages\n│   ├── HomePage\n│   ├── DetailPage\n│   └── SettingsPage\n└── Shared\n    ├── Button, Input, Card\n    └── Modal, Toast\n\`\`\`\n\nI've designed the architecture to be scalable and maintainable. Moving to task breakdown next.`,
    }),
  },
  {
    agentName: "Carol",
    agentRole: "Project Manager",
    thinkingDelay: 2000,
    generate: () => ({
      content: `## Task Breakdown\n\n1. **Project Setup** — Initialize project, install dependencies, configure build tools\n2. **Core Components** — Build reusable UI components (Button, Card, Input, Modal)\n3. **Page Layout** — Implement responsive layout with header and navigation\n4. **Main Feature** — Implement the primary functionality\n5. **Data Integration** — Connect to data layer, handle loading/error states\n6. **Styling & Polish** — Apply consistent theme, add animations\n7. **Testing** — Write unit tests for core logic\n8. **Documentation** — Add README and inline comments\n\nHanding off to the engineer now.`,
    }),
  },
  {
    agentName: "Dave",
    agentRole: "Engineer",
    thinkingDelay: 4000,
    generate: (prompt) => ({
      content: `## Code Generation Complete ✅\n\nI've generated the following files:\n\n\`\`\`\nsrc/\n├── components/\n│   ├── Header.tsx\n│   ├── Sidebar.tsx\n│   ├── Card.tsx\n│   └── Button.tsx\n├── pages/\n│   ├── index.tsx\n│   └── detail.tsx\n├── hooks/\n│   └── useData.ts\n├── utils/\n│   └── helpers.ts\n├── styles/\n│   └── globals.css\n└── App.tsx\n\`\`\`\n\nAll components are typed with TypeScript, styled with Tailwind, and follow React best practices. Ready for QA review.`,
    }),
  },
  {
    agentName: "Eve",
    agentRole: "QA Engineer",
    thinkingDelay: 2500,
    generate: () => ({
      content: `## QA Report ✅\n\n**Tests Run:** 12 | **Passed:** 11 | **Failed:** 1 (minor)\n\n### Results\n- ✅ Component rendering — all components render without errors\n- ✅ Navigation — routing works correctly between pages\n- ✅ Responsive design — layout adapts to mobile/tablet/desktop\n- ✅ Data flow — state updates propagate correctly\n- ✅ Error boundaries — graceful error handling verified\n- ⚠️ Edge case — empty state needs a placeholder message (auto-fixed)\n\n### Summary\nThe application is ready for deployment. All critical paths tested and verified. The one minor issue was auto-fixed during the review.\n\n🚀 **Project complete and ready to publish!**`,
    }),
  },
];

/* ------------------------------------------------------------------ */
/*  Runner                                                             */
/* ------------------------------------------------------------------ */

export type OnMessage = (msg: ChatMessage) => void;
export type OnUpdate = (msgId: string, patch: Partial<ChatMessage>) => void;
export type OnComplete = () => void;

/**
 * Runs the full agent pipeline for a given prompt.
 * Calls onMessage for each new message (thinking → resolved).
 * Returns an abort function.
 */
export function runAgentPipeline(
  prompt: string,
  onMessage: OnMessage,
  onUpdate: OnUpdate,
  onComplete: OnComplete,
): () => void {
  let aborted = false;
  const abort = () => {
    aborted = true;
  };

  (async () => {
    for (const step of pipeline) {
      if (aborted) break;

      // 1. Emit "thinking" message
      const thinkingId = `${Date.now()}-${step.agentRole}-thinking`;
      onMessage({
        id: thinkingId,
        role: "agent",
        agentName: step.agentName,
        agentRole: step.agentRole,
        content: "",
        thinking: true,
        timestamp: Date.now(),
      });

      // 2. Wait (simulate work)
      await delay(step.thinkingDelay);
      if (aborted) break;

      // 3. Generate response and replace thinking message
      const result = step.generate(prompt);
      onUpdate(thinkingId, {
        content: result.content,
        checklist: result.checklist,
        thinking: false,
      });

      // Small gap between agents
      await delay(800);
    }

    if (!aborted) {
      onComplete();
    }
  })();

  return abort;
}

function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
