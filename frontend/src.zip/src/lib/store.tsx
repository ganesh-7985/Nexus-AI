"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type AgentRole =
  | "Product Manager"
  | "Architect"
  | "Project Manager"
  | "Engineer"
  | "QA Engineer";

export interface ChatMessage {
  id: string;
  role: "user" | "agent";
  agentName?: string;
  agentRole?: AgentRole;
  content: string;
  thinking?: boolean;
  checklist?: { text: string; done: boolean }[];
  timestamp: number;
}

export type ProjectStatus = "running" | "completed" | "draft";

export interface Project {
  id: string;
  backendId?: string;
  name: string;
  prompt: string;
  status: ProjectStatus;
  color: string;
  messages: ChatMessage[];
  createdAt: number;
}

/* ------------------------------------------------------------------ */
/*  Context                                                            */
/* ------------------------------------------------------------------ */

interface StoreContextValue {
  projects: Project[];
  createProject: (prompt: string, name?: string) => Project;
  getProject: (id: string) => Project | undefined;
  addMessage: (projectId: string, msg: ChatMessage) => void;
  updateProject: (id: string, patch: Partial<Project>) => void;
  deleteProject: (id: string) => void;
}

const StoreContext = createContext<StoreContextValue | null>(null);

const STORAGE_KEY = "nexus_projects";

const randomColor = () => {
  const palette = [
    "#e8ddd3",
    "#d5e8d4",
    "#dae8fc",
    "#f8cecc",
    "#e1d5e7",
    "#fff2cc",
    "#d4e1f5",
    "#f5e0d0",
  ];
  return palette[Math.floor(Math.random() * palette.length)];
};

/* ------------------------------------------------------------------ */
/*  Provider                                                           */
/* ------------------------------------------------------------------ */

export function StoreProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loaded, setLoaded] = useState(false);

  // Hydrate from localStorage once on mount, then try loading from backend
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setProjects(JSON.parse(raw));
    } catch {
      /* ignore */
    }
    setLoaded(true);

    // Also try to load projects from backend (Supabase-backed)
    import("@/lib/api").then(({ listBackendProjects }) => {
      listBackendProjects()
        .then((backendProjects) => {
          if (backendProjects && Array.isArray(backendProjects) && backendProjects.length > 0) {
            setProjects((prev) => {
              const existingIds = new Set(prev.map((p) => p.backendId));
              const newFromBackend = backendProjects
                .filter((bp: any) => !existingIds.has(bp.id))
                .map((bp: any) => ({
                  id: bp.id,
                  backendId: bp.id,
                  name: bp.name,
                  prompt: bp.prompt,
                  status: (bp.status === "completed" ? "completed" : bp.status === "running" ? "running" : "draft") as ProjectStatus,
                  color: randomColor(),
                  messages: [],
                  createdAt: new Date(bp.created_at || Date.now()).getTime(),
                }));
              return newFromBackend.length > 0 ? [...prev, ...newFromBackend] : prev;
            });
          }
        })
        .catch(() => {}); // Backend may be offline
    });
  }, []);

  // Persist whenever projects change (skip initial empty render)
  useEffect(() => {
    if (loaded) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
    }
  }, [projects, loaded]);

  const createProject = useCallback(
    (prompt: string, name?: string): Project => {
      const project: Project = {
        id: Date.now().toString(),
        name: name || prompt.slice(0, 40) + (prompt.length > 40 ? "…" : ""),
        prompt,
        status: "running",
        color: randomColor(),
        messages: [
          {
            id: `${Date.now()}-user`,
            role: "user",
            content: prompt,
            timestamp: Date.now(),
          },
        ],
        createdAt: Date.now(),
      };
      setProjects((prev) => [project, ...prev]);
      return project;
    },
    [],
  );

  const getProject = useCallback(
    (id: string) => projects.find((p) => p.id === id),
    [projects],
  );

  const addMessage = useCallback((projectId: string, msg: ChatMessage) => {
    setProjects((prev) =>
      prev.map((p) =>
        p.id === projectId ? { ...p, messages: [...p.messages, msg] } : p,
      ),
    );
  }, []);

  const updateProject = useCallback(
    (id: string, patch: Partial<Project>) => {
      setProjects((prev) =>
        prev.map((p) => (p.id === id ? { ...p, ...patch } : p)),
      );
    },
    [],
  );

  const deleteProject = useCallback((id: string) => {
    setProjects((prev) => {
      const proj = prev.find((p) => p.id === id);
      if (proj?.backendId) {
        import("@/lib/api").then(({ deleteBackendProject }) => {
          deleteBackendProject(proj.backendId!).catch(() => {});
        });
      }
      return prev.filter((p) => p.id !== id);
    });
  }, []);

  const value = useMemo(
    () => ({
      projects,
      createProject,
      getProject,
      addMessage,
      updateProject,
      deleteProject,
    }),
    [projects, createProject, getProject, addMessage, updateProject, deleteProject],
  );

  return (
    <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
